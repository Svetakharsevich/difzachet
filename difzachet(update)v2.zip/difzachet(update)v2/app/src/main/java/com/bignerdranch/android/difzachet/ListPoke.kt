package com.bignerdranch.android.difzachet

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ListPoke : AppCompatActivity() {
    lateinit var list:ListView
    private lateinit var pokeList: MutableList<String>
    lateinit var shar: SharedPreferences
    var nameShared:String = "MyShared"
    var Pokemons:String = "Pokemon"
    private lateinit var backbut: Button
    private lateinit var addbut: Button
    private lateinit var addbut2: Button
    private lateinit var cancelbut: Button
    private lateinit var addtxtpoke: EditText
    private lateinit var addtxtexp: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_poke)
        backbut = findViewById(R.id.backButton)
        addbut = findViewById(R.id.addButton)
        addbut2 = findViewById(R.id.addButtontwo)
        addtxtpoke = findViewById(R.id.addtextpoke)
        addtxtexp = findViewById(R.id.addtextexp)
        cancelbut = findViewById(R.id.cancelButton)
        pokeList = mutableListOf()
        list = findViewById(R.id.lsv)
        shar = getSharedPreferences(nameShared, MODE_PRIVATE)
        val poke = shar.getString(Pokemons,null)
        if(!poke.isNullOrEmpty()){
            pokeList.add(poke)
            val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, pokeList)
            list.adapter = adapter
        }

        addbut.setOnClickListener {
            addtxtpoke.visibility= View.VISIBLE
            addtxtexp.visibility = View.VISIBLE
            addbut2.visibility = View.VISIBLE
            cancelbut.visibility = View.VISIBLE

            addbut2.setOnClickListener {

                if(!addtxtpoke.text.toString().isNullOrEmpty() && !addtxtexp.text.toString().isNullOrEmpty()){

                    if(isNumeric(addtxtexp.text.toString())) {
                        pokeList.add("Имя: ${addtxtpoke.text.toString()}  опыт: ${addtxtexp.text.toString()}")
                        addtxtpoke.visibility = View.INVISIBLE
                        addtxtexp.visibility = View.INVISIBLE
                        addbut2.visibility = View.INVISIBLE
                        cancelbut.visibility = View.INVISIBLE
                        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, pokeList)
                        list.adapter = adapter
                    }
                    else{
                        Toast.makeText(this, "Неправильное значение опыта", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(this, "Обнаружено пустое поле", Toast.LENGTH_SHORT).show();
                }

            }

        }
        cancelbut.setOnClickListener {
            cancelbut.visibility = View.INVISIBLE
            addtxtpoke.visibility= View.INVISIBLE
            addtxtexp.visibility = View.INVISIBLE
            addbut2.visibility = View.INVISIBLE
            addtxtpoke.text=null
            addtxtexp.text=null
        }

        backbut.setOnClickListener {
            val intent = Intent(this,PokemonActivity::class.java)
            startActivity(intent)
        }


    }
    fun isNumeric(str: String): Boolean {
        try {
            val d = str.toInt()
        } catch (nfe: NumberFormatException) {
            return false
        }
        return true
    }
}