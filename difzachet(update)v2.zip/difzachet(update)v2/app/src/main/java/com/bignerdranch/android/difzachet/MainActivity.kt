package com.bignerdranch.android.difzachet

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var startbut: Button
    lateinit var login: EditText
    lateinit var password: EditText
    lateinit var shar: SharedPreferences
    lateinit var editor: SharedPreferences.Editor
    var nameShared:String = "MyShared"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var log:String=""
        var pass:String=""
        login =  findViewById(R.id.logintext)
        password = findViewById(R.id.passtext)
        shar = getSharedPreferences(nameShared, MODE_PRIVATE)
        editor = shar.edit()
        startbut = findViewById(R.id.startbut)
        /*editor.clear()
        editor.apply()*/
        if(shar.contains("login") && shar.contains("password")) {
            log = shar.getString("login", "").toString();
            pass = shar.getString("password", "").toString();
        }
        else{
            Toast.makeText(this, "Задайте логин и пароль", Toast.LENGTH_SHORT).show();
            startbut.text = "Зарегистрироваться"
        }
        //editor.putString(nameShared,"###");
        /*val intent =Intent(this,SecondActivity::class.java)
        startActivity(intent)*/
        startbut.setOnClickListener {

            if(login.text.isEmpty() || password.text.isEmpty()){
                Toast.makeText(this, "Пустое поле ввода логина или пароля", Toast.LENGTH_SHORT).show();
            }
            else{
                if(log==login.text.toString() && pass==password.text.toString()){
                    val intent = Intent(this,PokemonActivity::class.java)
                    startActivity(intent)
                }
                else{
                    Toast.makeText(this, "Неправильный логин или пароль", Toast.LENGTH_SHORT).show();
                }
            }

        }

    }
}