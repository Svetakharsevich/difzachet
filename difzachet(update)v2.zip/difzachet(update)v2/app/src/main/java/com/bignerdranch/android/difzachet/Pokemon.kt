package com.bignerdranch.android.difzachet

class Pokemon(
val name: String,
val exp: String,
val height:Int,
val weight:Int)