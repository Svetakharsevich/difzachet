package com.bignerdranch.android.difzachet

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.snackbar.Snackbar
import org.json.JSONObject

class PokemonActivity : AppCompatActivity() {
    lateinit var txt: TextView
    lateinit var edtxtx: EditText
    lateinit var but: Button
    lateinit var hbut: Button
    lateinit var shar: SharedPreferences
    lateinit var editor: SharedPreferences.Editor
    var nameShared:String = "MyShared"
    var Pokemons:String = "Pokemon"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pokemon)

        shar = getSharedPreferences(nameShared, MODE_PRIVATE)
        editor = shar.edit()
        edtxtx = findViewById(R.id.nametext)
        but = findViewById(R.id.wbut)
        hbut = findViewById(R.id.hbut)
        txt = findViewById(R.id.textView)
        but.setOnClickListener {
            if(edtxtx.text.isNotEmpty() && edtxtx.text != null){
                pokemon(edtxtx.text.toString())
            }
            else{
                val sn = Snackbar.make(findViewById(android.R.id.content),R.string.pods, Snackbar.LENGTH_LONG)
                sn.show()
                txt.text=null

            }

        }

        hbut.setOnClickListener {
            val intent = Intent(this,ListPoke::class.java)
            startActivity(intent)
        }

    }
    private fun pokemon(poke:String){
        var url="https://pokeapi.co/api/v2/pokemon/${poke}"
        var name:String=""
        var baseExp:String=""
        var height:Int=0
        var weight:Int=0
        val queue = Volley.newRequestQueue(this)
        val stringRequest = StringRequest(
            Request.Method.GET,
            url,
            {
                    response ->
                val obj = JSONObject(response)
                name = obj.getString("name")
                baseExp = obj.getString("base_experience")
                height = obj.getInt("height")
                weight = obj.getInt("weight")
                txt.text = "Имя: $name \nОпыт: $baseExp\nРост: $height\nШирина: $weight"
                val pokemon = "Имя: $name Опыт: $baseExp\nРост: $height\nШирина: $weight"
                editor.putString(Pokemons,pokemon)
                editor.apply()


            },
            {
                txt.text = null
                val sn = Snackbar.make(findViewById(android.R.id.content),R.string.pods2,Snackbar.LENGTH_LONG)
                sn.show()
                Log.d("MyLog","Volley error: $it")
            }
        )
        queue.add(stringRequest)


    }
}